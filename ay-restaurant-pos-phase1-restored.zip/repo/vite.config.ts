import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
export default defineConfig({plugins:[react(),VitePWA({registerType:'autoUpdate',
 workbox:{globPatterns:['**/*.{js,css,html,png,svg,woff2}']},
 manifest:{name:'AY Restaurant POS',short_name:'AY POS',lang:'ar',dir:'rtl',display:'standalone',
 background_color:'#0a1530',theme_color:'#0a1530',start_url:'/',
 icons:[{src:'logo.png',sizes:'512x512',type:'image/png',purpose:'any'}]}})]});
