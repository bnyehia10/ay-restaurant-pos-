# AY Restaurant POS — Phase 1
نظام إدارة المطاعم والكاشير — يعمل بدون إنترنت. By AY Digital Solutions (official logo: `public/logo.png`, unmodified).

## Structure
`src/{components,pages,layouts,database,services,hooks,types,utils,data,styles,assets}`
- `database/db.ts` raw IndexedDB layer (DB `AY_Restaurant_POS`, 21 stores); `seed.ts` first-run demo data
- `services/` auth (roles/permissions), backup (JSON export/import)
- `utils/hash.ts` password hashing abstraction (PBKDF2-SHA256, per-user salt)

## Install / Dev / Build
```
npm install     # needs internet once
npm run dev
npm run build && npm run preview
```
## Offline
Build, open once (service worker caches assets), then install from the browser. No external runtime requests; system fonts only.
Service workers and Web Crypto need `localhost` or HTTPS.

## Default development login
`admin` / `admin123` — DEVELOPMENT account; change it in Settings.

## Roadmap
2: Products/Categories CRUD + POS cart · 3: Orders, tables, kitchen · 4: Inventory, recipes, purchases · 5: Customers, suppliers, expenses, reports · 6: Users UI, ESC/POS printing, auto-backup · 7: English i18n
