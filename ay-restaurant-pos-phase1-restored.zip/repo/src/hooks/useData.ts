import {useCallback,useEffect,useRef,useState} from 'react';

/** Reconstructed from the existing call sites (Categories, Dashboard, Orders, POS, Products) and StateBox's prop types. */
export interface UseDataResult<T>{data:T|null;loading:boolean;error:string;reload:()=>Promise<void>}

/**
 * Runs an async loader once on mount and again on reload().
 * - loading is true only until the first load settles, so reload() keeps the current data on screen
 *   (StateBox replaces its children while loading is true).
 * - error is always a string ('' when none), as StateBox requires.
 * - The loader may be an inline arrow: the latest one is read through a ref, so it never triggers re-runs.
 * - Stale/overlapping loads and loads finishing after unmount are ignored.
 */
export function useData<T>(loader:()=>Promise<T>):UseDataResult<T>{
 const loaderRef=useRef(loader);loaderRef.current=loader;
 const mounted=useRef(true);const seq=useRef(0);
 const[data,setData]=useState<T|null>(null);const[loading,setLoading]=useState(true);const[error,setError]=useState('');
 const reload=useCallback(async()=>{
  const id=++seq.current;const live=()=>mounted.current&&id===seq.current;
  try{const r=await loaderRef.current();if(live()){setData(r);setError('')}}
  catch(e){console.error('[useData] load failed',e);if(live())setError(e instanceof Error&&e.message?e.message:'تعذر تحميل البيانات')}
  finally{if(live())setLoading(false)}
 },[]);
 useEffect(()=>{mounted.current=true;void reload();return()=>{mounted.current=false}},[reload]);
 return{data,loading,error,reload};
}
