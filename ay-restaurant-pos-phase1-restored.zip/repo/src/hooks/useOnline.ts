import {useEffect,useState} from 'react';
export function useNow(){const[n,s]=useState(new Date());useEffect(()=>{const t=setInterval(()=>s(new Date()),1000);return()=>clearInterval(t)},[]);return n;}
export function useOnline(){const[o,s]=useState(navigator.onLine);useEffect(()=>{const a=()=>s(true),b=()=>s(false);addEventListener('online',a);addEventListener('offline',b);return()=>{removeEventListener('online',a);removeEventListener('offline',b)}},[]);return o;}
