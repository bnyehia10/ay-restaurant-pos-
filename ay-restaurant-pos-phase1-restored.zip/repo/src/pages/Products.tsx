import {useState} from 'react';import {repo} from '../database/db';import type {Category,Product} from '../types';import {useData} from '../hooks/useData';
import {saveProduct,type ProductInput} from '../services/catalog';import {useToast} from '../components/Toast';import {Modal,Confirm,StateBox} from '../components/Modal';import {ImagePick} from '../components/ImagePick';import {money} from '../utils/hash';
const STATIONS:[string,string][]=[['','بدون'],['grill','الشواية'],['fry','القلاية'],['oven','الفرن'],['drinks','المشروبات']];
export default function Products(){const toast=useToast();const[q,setQ]=useState('');const[cat,setCat]=useState('');const[st,setSt]=useState('');const[edit,setEdit]=useState<ProductInput|null>(null);const[del,setDel]=useState<Product|null>(null);const[err,setErr]=useState('');
 const{data,loading,error,reload}=useData(async()=>({c:await repo.all<Category>('categories'),p:await repo.all<Product>('products')}));
 const cn=(id:string)=>data?.c.find(c=>c.id===id)?.name??'—';
 const list=(data?.p??[]).filter(p=>(!q.trim()||p.name.includes(q.trim())||p.barcode===q.trim())&&(!cat||p.categoryId===cat)&&(!st||(st==='1')===p.active));
 const save=async(p:ProductInput,ok='تم حفظ الصنف')=>{try{await saveProduct(p);toast(ok);setEdit(null);setErr('');reload()}catch(e){setErr((e as Error).message);toast((e as Error).message,'err')}};
 const open=(p?:Product)=>{setErr('');setEdit(p?{...p,sellingPrice:String(p.sellingPrice),costPrice:String(p.costPrice)}:{sellingPrice:'',costPrice:'0',active:true,unit:'قطعة',categoryId:data?.c[0]?.id})};
 return <><div className="bar2"><input placeholder="بحث بالاسم أو الباركود" value={q} onChange={e=>setQ(e.target.value)}/>
 <select value={cat} onChange={e=>setCat(e.target.value)}><option value="">كل الأقسام</option>{data?.c.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select>
 <select value={st} onChange={e=>setSt(e.target.value)}><option value="">الكل</option><option value="1">مفعل</option><option value="0">معطل</option></select>
 <button className="btn" onClick={()=>open()} disabled={!data?.c.length}>+ صنف جديد</button></div>
 <StateBox loading={loading} error={error} empty={!list.length?'لا توجد أصناف مطابقة.':''}><div className="card scroll"><table className="tbl"><thead><tr><th>الصنف</th><th>القسم</th><th>الباركود</th><th>السعر</th><th>التكلفة</th><th>الحالة</th><th></th></tr></thead><tbody>{list.map(p=><tr key={p.id}>
 <td>{p.name}{p.isDemo&&<small className="muted"> (تجريبي)</small>}</td><td>{cn(p.categoryId)}</td><td>{p.barcode??'—'}</td><td>{money(p.sellingPrice)}</td><td>{money(p.costPrice)}</td>
 <td><button className={'pill '+(p.active?'on':'')} onClick={()=>save({...p,sellingPrice:String(p.sellingPrice),costPrice:String(p.costPrice),active:!p.active},'تم تحديث الحالة')}>{p.active?'مفعل':'معطل'}</button></td>
 <td className="acts"><button className="link" onClick={()=>open(p)}>تعديل</button><button className="link red" onClick={()=>setDel(p)}>حذف</button></td></tr>)}</tbody></table></div></StateBox>
 {edit&&<Modal title={edit.id?'تعديل صنف':'صنف جديد'} onClose={()=>setEdit(null)}><div className="form2">
 <label>الاسم *<input value={edit.name??''} onChange={e=>setEdit({...edit,name:e.target.value})} autoFocus/></label>
 <label>القسم *<select value={edit.categoryId??''} onChange={e=>setEdit({...edit,categoryId:e.target.value})}><option value="">اختر القسم</option>{data?.c.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
 <label>سعر البيع *<input type="number" min="0" step="0.01" value={edit.sellingPrice} onChange={e=>setEdit({...edit,sellingPrice:e.target.value})}/></label>
 <label>سعر التكلفة<input type="number" min="0" step="0.01" value={edit.costPrice} onChange={e=>setEdit({...edit,costPrice:e.target.value})}/></label>
 <label>الباركود<input value={edit.barcode??''} onChange={e=>setEdit({...edit,barcode:e.target.value})}/></label>
 <label>الوحدة<input value={edit.unit??''} onChange={e=>setEdit({...edit,unit:e.target.value})}/></label>
 <label>محطة المطبخ<select value={edit.kitchenStation??''} onChange={e=>setEdit({...edit,kitchenStation:e.target.value})}>{STATIONS.map(([v,l])=><option key={v} value={v}>{l}</option>)}</select></label>
 <label>الصورة<ImagePick value={edit.image} onChange={v=>setEdit({...edit,image:v})}/></label></div>
 <label>الوصف<input value={edit.description??''} onChange={e=>setEdit({...edit,description:e.target.value})}/></label>
 <label className="chk"><input type="checkbox" checked={edit.active??true} onChange={e=>setEdit({...edit,active:e.target.checked})}/>مفعل</label>
 <label className="chk"><input type="checkbox" checked={!!edit.hasRecipe} onChange={e=>setEdit({...edit,hasRecipe:e.target.checked})}/>له وصفة (تُفعّل لاحقًا)</label>
 {err&&<div className="errtxt">{err}</div>}<div className="acts"><button className="btn" onClick={()=>save(edit)}>حفظ</button><button className="btn ghost" onClick={()=>setEdit(null)}>إلغاء</button></div></Modal>}
 {del&&<Confirm message={`حذف الصنف «${del.name}»؟ لن تتأثر الفواتير السابقة.`} onNo={()=>setDel(null)} onYes={async()=>{await repo.remove('products',del.id);toast('تم حذف الصنف');setDel(null);reload()}}/>}</>}
