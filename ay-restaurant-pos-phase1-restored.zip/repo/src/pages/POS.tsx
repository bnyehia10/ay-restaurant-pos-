import {useEffect,useRef,useState} from 'react';import {repo} from '../database/db';import type {Category,Order,PayMethod,Product,User} from '../types';
import {useData} from '../hooks/useData';import {calculateTotals,PAY_LABEL,type DiscountType} from '../utils/calc';import {createOrder} from '../services/orders';import {getSetting,getTaxRate} from '../services/settings';
import {useToast} from '../components/Toast';import {Modal,StateBox} from '../components/Modal';import {Receipt} from '../components/Receipt';import {money} from '../utils/hash';
interface Line{productId:string;name:string;price:number;qty:number}
function PayModal({total,onClose,onOk}:{total:number;onClose:()=>void;onOk:(m:PayMethod,paid:number)=>Promise<void>}){
 const[m,setM]=useState<PayMethod>('cash');const[paid,setPaid]=useState(String(total));const[busy,setBusy]=useState(false);
 const p=Number(paid)||0;const change=m==='cash'?Math.max(0,p-total):0;const bad=m==='cash'&&p<total;
 return <Modal title="الدفع" onClose={onClose}><div className="big2">إجمالي الفاتورة: <b>{money(total)}</b></div>
 <div className="paym">{(['cash','card','credit'] as PayMethod[]).map(k=><button key={k} className={'btn '+(m===k?'':'ghost')} onClick={()=>setM(k)}>{PAY_LABEL[k]}</button>)}</div>
 {m==='cash'&&<><label>المبلغ المدفوع<input type="number" min="0" step="0.01" value={paid} onChange={e=>setPaid(e.target.value)} autoFocus onFocus={e=>e.target.select()}/></label><div className="big2">الباقي: <b>{money(change)}</b></div>{bad&&<div className="errtxt">المبلغ المدفوع أقل من إجمالي الفاتورة</div>}</>}
 {m==='credit'&&<p className="muted">سيُسجَّل الطلب كآجل بدون تحصيل مبلغ الآن.</p>}
 <div className="acts"><button className="btn" disabled={bad||busy} onClick={async()=>{setBusy(true);try{await onOk(m,m==='cash'?p:m==='card'?total:0)}finally{setBusy(false)}}}>{busy?'جارٍ الحفظ...':'تأكيد الدفع'}</button><button className="btn ghost" onClick={onClose}>إلغاء</button></div></Modal>}
export default function POS({user}:{user:User}){
 const toast=useToast();const search=useRef<HTMLInputElement>(null);
 const{data,loading,error}=useData(async()=>({cats:(await repo.all<Category>('categories')).filter(c=>c.active),prods:(await repo.all<Product>('products')).filter(p=>p.active),tax:await getTaxRate(),name:await getSetting('restaurantName','')}));
 const[cart,setCart]=useState<Line[]>([]);const[sel,setSel]=useState<string|null>(null);const[cat,setCat]=useState('');const[q,setQ]=useState('');
 const[dt,setDt]=useState<DiscountType>('none');const[dv,setDv]=useState('');const[paying,setPaying]=useState(false);const[done,setDone]=useState<Order|null>(null);
 const t=calculateTotals(cart,dt,Number(dv)||0,data?.tax??0);
 const add=(p:Product)=>{setCart(c=>c.some(l=>l.productId===p.id)?c.map(l=>l.productId===p.id?{...l,qty:l.qty+1}:l):[...c,{productId:p.id,name:p.name,price:p.sellingPrice,qty:1}]);setSel(p.id)};
 const chg=(id:string,d:number)=>setCart(c=>c.map(l=>l.productId===id?{...l,qty:l.qty+d}:l).filter(l=>l.qty>0));
 const rm=(id:string)=>{setCart(c=>c.filter(l=>l.productId!==id));setSel(null)};
 const reset=()=>{setCart([]);setSel(null);setDt('none');setDv('');setDone(null);setPaying(false);setQ('')};
 useEffect(()=>{const h=(e:KeyboardEvent)=>{if(e.key==='F2'){e.preventDefault();search.current?.focus()}
  else if(e.key==='F4'){e.preventDefault();if(cart.length&&!done)setPaying(true)}
  else if(e.key==='Delete'&&sel&&!(e.target instanceof HTMLInputElement)&&!paying&&!done)rm(sel)};
  addEventListener('keydown',h);return()=>removeEventListener('keydown',h)},[cart,sel,done,paying]);
 const prods=(data?.prods??[]).filter(p=>(!cat||p.categoryId===cat)&&(!q.trim()||p.name.includes(q.trim())||p.barcode===q.trim()));
 const pay=async(m:PayMethod,paid:number)=>{try{const o=await createOrder({items:cart.map(({productId,name,qty,price})=>({productId,name,qty,price})),subtotal:t.subtotal,discountType:dt,discountValue:Number(dv)||0,discount:t.discount,tax:t.tax,taxRate:data?.tax??0,total:t.total,paymentMethod:m,paidAmount:paid,change:m==='cash'?Math.round((paid-t.total)*100)/100:0,cashierId:user.id,cashierName:user.name});setPaying(false);setDone(o);toast('تم حفظ الطلب '+o.orderNumber)}catch(e){toast('تعذر حفظ الطلب: '+(e as Error).message,'err')}};
 return <StateBox loading={loading} error={error}><div className="pos"><div className="pos-main">
 <input ref={search} className="psearch" placeholder="بحث بالاسم أو الباركود (F2)" value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'){const p=data?.prods.find(x=>x.barcode&&x.barcode===q.trim());if(p){add(p);setQ('')}}}}/>
 <div className="chips"><button className={'chip '+(!cat?'on':'')} onClick={()=>setCat('')}>الكل</button>{data?.cats.map(c=><button key={c.id} className={'chip '+(cat===c.id?'on':'')} style={{borderColor:c.color}} onClick={()=>setCat(c.id)}>{c.name}</button>)}</div>
 {!prods.length?<div className="card empty">لا توجد أصناف مطابقة. أضف أصنافًا من صفحة الأصناف.</div>:
 <div className="pgrid">{prods.map(p=><button key={p.id} className="pcard" onClick={()=>add(p)}>{p.image&&<img src={p.image} alt=""/>}<b>{p.name}</b><small>{data?.cats.find(c=>c.id===p.categoryId)?.name}</small><span>{money(p.sellingPrice)}</span></button>)}</div>}</div>
 <aside className="cart card"><h3>الطلب الحالي</h3><div className="lines">{!cart.length?<p className="muted">السلة فارغة — اضغط على صنف لإضافته.</p>:cart.map(l=><div key={l.productId} className={'line '+(sel===l.productId?'sel':'')} onClick={()=>setSel(l.productId)}>
 <div><b>{l.name}</b><small>{money(l.price)}</small></div><div className="qty"><button onClick={()=>chg(l.productId,-1)} aria-label="إنقاص">−</button><span>{l.qty}</span><button onClick={()=>chg(l.productId,1)} aria-label="زيادة">+</button></div><span>{money(l.qty*l.price)}</span><button className="link red" onClick={()=>rm(l.productId)} aria-label="حذف">✕</button></div>)}</div>
 <div className="disc"><select value={dt} onChange={e=>setDt(e.target.value as DiscountType)}><option value="none">بدون خصم</option><option value="percent">خصم %</option><option value="fixed">خصم مبلغ</option></select>{dt!=='none'&&<input type="number" min="0" value={dv} onChange={e=>setDv(e.target.value)} placeholder="القيمة"/>}</div>
 <div className="tot"><div><span>الإجمالي الفرعي</span><span>{money(t.subtotal)}</span></div><div><span>الخصم</span><span>{money(t.discount)}</span></div><div><span>الضريبة ({Math.round((data?.tax??0)*10000)/100}%)</span><span>{money(t.tax)}</span></div><div className="gt"><span>الإجمالي</span><span>{money(t.total)}</span></div></div>
 <button className="btn pay" disabled={!cart.length} onClick={()=>setPaying(true)}>دفع (F4)</button><button className="btn ghost" disabled={!cart.length} onClick={()=>{if(confirm('مسح كل الأصناف من السلة؟'))reset()}}>مسح السلة</button></aside></div>
 {paying&&<PayModal total={t.total} onClose={()=>setPaying(false)} onOk={pay}/>}
 {done&&<Modal title="الفاتورة" onClose={reset}><Receipt order={done} restaurant={data?.name??''}/><div className="acts"><button className="btn" onClick={()=>window.print()}>طباعة</button><button className="btn ghost" onClick={reset}>فاتورة جديدة</button></div></Modal>}</StateBox>}
