import {useState} from 'react';import {repo} from '../database/db';import type {Category,Product} from '../types';import {useData} from '../hooks/useData';
import {saveCategory,deleteCategory} from '../services/catalog';import {useToast} from '../components/Toast';import {Modal,Confirm,StateBox} from '../components/Modal';import {ImagePick} from '../components/ImagePick';
export default function Categories(){const toast=useToast();const[q,setQ]=useState('');const[edit,setEdit]=useState<Partial<Category>|null>(null);const[del,setDel]=useState<Category|null>(null);
 const{data,loading,error,reload}=useData(async()=>({c:await repo.all<Category>('categories'),p:await repo.all<Product>('products')}));
 const run=async(f:()=>Promise<void>,ok:string)=>{try{await f();toast(ok);setEdit(null);setDel(null);reload()}catch(e){toast((e as Error).message,'err');setDel(null)}};
 const list=(data?.c??[]).filter(c=>c.name.includes(q.trim()));
 return <><div className="bar2"><input placeholder="بحث في الأقسام" value={q} onChange={e=>setQ(e.target.value)}/><button className="btn" onClick={()=>setEdit({color:'#2f7bff',active:true})}>+ قسم جديد</button></div>
 <StateBox loading={loading} error={error} empty={!list.length?'لا توجد أقسام مطابقة. أضف قسمًا جديدًا للبدء.':''}>
 <div className="card"><table className="tbl"><thead><tr><th>القسم</th><th>الأصناف</th><th>الحالة</th><th></th></tr></thead><tbody>{list.map(c=><tr key={c.id}>
 <td><span className="sw" style={{background:c.color}}/>{c.name}</td><td>{data!.p.filter(p=>p.categoryId===c.id).length}</td>
 <td><button className={'pill '+(c.active?'on':'')} onClick={()=>run(()=>saveCategory({...c,active:!c.active}),'تم تحديث الحالة')}>{c.active?'مفعل':'معطل'}</button></td>
 <td className="acts"><button className="link" onClick={()=>setEdit(c)}>تعديل</button><button className="link red" onClick={()=>setDel(c)}>حذف</button></td></tr>)}</tbody></table></div></StateBox>
 {edit&&<Modal title={edit.id?'تعديل قسم':'قسم جديد'} onClose={()=>setEdit(null)}><label>الاسم *<input value={edit.name??''} onChange={e=>setEdit({...edit,name:e.target.value})} autoFocus/></label>
 <label>اللون<input type="color" value={edit.color} onChange={e=>setEdit({...edit,color:e.target.value})}/></label><label>الصورة<ImagePick value={edit.image} onChange={v=>setEdit({...edit,image:v})}/></label>
 <label className="chk"><input type="checkbox" checked={edit.active??true} onChange={e=>setEdit({...edit,active:e.target.checked})}/>مفعل</label>
 <div className="acts"><button className="btn" onClick={()=>run(()=>saveCategory(edit),'تم حفظ القسم')}>حفظ</button><button className="btn ghost" onClick={()=>setEdit(null)}>إلغاء</button></div></Modal>}
 {del&&<Confirm message={`هل تريد حذف القسم «${del.name}»؟`} onNo={()=>setDel(null)} onYes={()=>run(()=>deleteCategory(del.id),'تم حذف القسم')}/>}</>}
