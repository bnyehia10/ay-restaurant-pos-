import {useRef,useState} from 'react';import {exportDatabase,importDatabase} from '../services/backup';import {useToast} from '../components/Toast';
export default function Backup(){const f=useRef<HTMLInputElement>(null);const toast=useToast();const[file,setFile]=useState<File|null>(null);
 return <div className="card"><h2>النسخ الاحتياطي والاستعادة</h2><p className="muted">ملف JSON يحتوي كل البيانات المحلية.</p>
 <button className="btn" onClick={async()=>{try{await exportDatabase();toast('تم تصدير النسخة')}catch(e){toast((e as Error).message,'err')}}}>تصدير قاعدة البيانات</button>
 <hr/><input ref={f} type="file" accept=".json" onChange={e=>setFile(e.target.files?.[0]??null)}/>
 <button className="btn danger" disabled={!file} onClick={async()=>{if(!file||!confirm('سيتم استبدال كل البيانات الحالية. هل أنت متأكد؟'))return;try{await importDatabase(file);toast('تمت الاستعادة، سيُعاد التحميل');setTimeout(()=>location.reload(),1200)}catch(e){toast((e as Error).message,'err')}}}>استيراد واستعادة</button></div>}
