import {useState} from 'react';import {useData} from '../hooks/useData';import {listOrders} from '../services/orders';import {getSetting} from '../services/settings';import type {Order} from '../types';
import {Modal,StateBox} from '../components/Modal';import {Receipt} from '../components/Receipt';import {money} from '../utils/hash';import {PAY_LABEL} from '../utils/calc';
export default function Orders(){const[q,setQ]=useState('');const[v,setV]=useState<Order|null>(null);
 const{data,loading,error}=useData(async()=>({o:await listOrders(),n:await getSetting('restaurantName','')}));
 const list=(data?.o??[]).filter(o=>o.orderNumber.toLowerCase().includes(q.trim().toLowerCase()));
 return <><div className="bar2"><input placeholder="بحث برقم الطلب" value={q} onChange={e=>setQ(e.target.value)}/></div>
 <StateBox loading={loading} error={error} empty={!list.length?(q?'لا توجد نتائج.':'لا توجد طلبات بعد. أتمم أول عملية بيع من شاشة الكاشير.'):''}><div className="card scroll"><table className="tbl"><thead><tr><th>رقم الطلب</th><th>التاريخ</th><th>الكاشير</th><th>الإجمالي</th><th>الدفع</th><th>الحالة</th><th></th></tr></thead><tbody>{list.map(o=><tr key={o.id}>
 <td>{o.orderNumber}</td><td>{new Date(o.createdAt).toLocaleString('ar-EG')}</td><td>{o.cashierName}</td><td>{money(o.total)}</td><td>{PAY_LABEL[o.paymentMethod]}</td><td>{o.status==='completed'?'مكتمل':'ملغي'}</td><td><button className="link" onClick={()=>setV(o)}>عرض الفاتورة</button></td></tr>)}</tbody></table></div></StateBox>
 {v&&<Modal title={'الطلب '+v.orderNumber} onClose={()=>setV(null)}><Receipt order={v} restaurant={data?.n??''}/><div className="acts"><button className="btn" onClick={()=>window.print()}>طباعة</button><button className="btn ghost" onClick={()=>setV(null)}>إغلاق</button></div></Modal>}</>}
