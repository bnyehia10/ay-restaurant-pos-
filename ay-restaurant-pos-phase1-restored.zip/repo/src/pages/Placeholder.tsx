export default function Placeholder({title}:{title:string}){return <div className="card empty"><h2>{title}</h2><p>هذه الشاشة قيد التطوير وستتوفر في مرحلة قادمة.</p></div>}
