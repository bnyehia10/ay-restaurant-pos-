import {useState} from 'react';import logo from '../assets/logo.png';import {login} from '../services/auth';import type {User} from '../types';import {useToast} from '../components/Toast';
export default function Login({onDone}:{onDone:(u:User)=>void}){
 const[u,setU]=useState('');const[p,setP]=useState('');const[busy,setBusy]=useState(false);const[e,setE]=useState('');const toast=useToast();
 async function submit(){if(!u.trim()||!p){setE('أدخل اسم المستخدم وكلمة المرور');return}setBusy(true);setE('');
  try{const r=await login(u.trim(),p);if(r){toast('أهلًا '+r.name);onDone(r)}else setE('بيانات الدخول غير صحيحة')}catch(x){setE((x as Error).message)}finally{setBusy(false)}}
 return <div className="center"><div className="card login" onKeyDown={ev=>ev.key==='Enter'&&submit()}>
 <img src={logo} alt="AY Digital Solutions" className="logo-md"/><h2>AY Restaurant POS</h2><p className="muted">Smart Restaurant Management System</p>
 <input placeholder="اسم المستخدم" value={u} onChange={x=>setU(x.target.value)} autoFocus/><input type="password" placeholder="كلمة المرور" value={p} onChange={x=>setP(x.target.value)}/>
 {e&&<div className="errtxt">{e}</div>}<button className="btn" disabled={busy} onClick={submit}>{busy?'جارٍ الدخول...':'تسجيل الدخول'}</button>
 <div className="dev">⚠ حساب تطوير افتراضي (DEVELOPMENT): admin / admin123 — غيّر كلمة المرور من الإعدادات.</div></div></div>}
