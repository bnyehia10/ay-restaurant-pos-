import logo from '../assets/logo.png';
export default function Splash(){return <div className="center splash"><img src={logo} alt="AY Digital Solutions" className="logo-lg"/><h1>AY Restaurant POS</h1><p>نظام إدارة المطاعم والكاشير</p><span className="badge">يعمل بدون إنترنت</span></div>}
