import logo from '../assets/logo.png';
export default function About(){return <div className="card center-col"><img src={logo} alt="AY Digital Solutions" className="logo-md"/><h2>AY Restaurant POS</h2><p>الحلول الرقمية — AY for Digital Solutions</p><p className="muted">الإصدار 0.1.0 (المرحلة 1) — يعمل بالكامل بدون إنترنت</p></div>}
