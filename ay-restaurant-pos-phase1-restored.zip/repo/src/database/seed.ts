import {repo,openDB} from './db';import {DEMO_CATEGORIES,DEMO_PRODUCTS,ROLES,DEMO_TABLES} from '../data/demo';
import {hashPassword,newSalt} from '../utils/hash';import type {User} from '../types';
export async function initDatabase(){
 await openDB();
 if(await repo.count('users')===0)await firstRun();await migratePhase2();}
async function firstRun(){
 const salt=newSalt();
 const admin:User={id:'u-admin',username:'admin',name:'مدير النظام',role:'ADMIN',salt,passwordHash:await hashPassword('admin123',salt),active:true,isDevDefault:true};
 await repo.put('users',admin);await repo.putMany('roles',ROLES);await repo.putMany('categories',DEMO_CATEGORIES);
 await repo.putMany('products',DEMO_PRODUCTS);await repo.putMany('tables',DEMO_TABLES);
 await repo.putMany('settings',[{key:'restaurantName',value:'مطعم تجريبي'},{key:'taxRate',value:0},{key:'language',value:'ar'}]);}

import type {Product} from '../types';
const X=(i:number,name:string,c:string,price:number,cost:number,st:string):Product=>({id:'p'+i,name,categoryId:c,sellingPrice:price,costPrice:cost,unit:'قطعة',active:true,hasRecipe:false,kitchenStation:st,createdAt:0,updatedAt:0,isDemo:true});
// Phase 2: adds more DEMO products once (flag-guarded, fixed ids => never duplicated).
async function migratePhase2(){
 if(await repo.get('settings','phase2Seed'))return;
 await repo.putMany('products',[X(12,'ستريبس فراخ','c3',95,40,'fry'),X(13,'ناجتس','c3',70,30,'fry'),X(14,'بيتزا مشكل','c2',150,70,'oven'),X(15,'سلطة سيزر','c5',60,22,''),X(16,'عصير برتقال','c6',35,15,''),X(17,'تشيز كيك','c7',80,32,''),X(18,'وجبة برجر كومبو','c4',140,65,'grill')]);
 if((await repo.get<{value:number}>('settings','taxRate'))?.value===0.14)await repo.put('settings',{key:'taxRate',value:0});
 await repo.put('settings',{key:'phase2Seed',value:true});}
