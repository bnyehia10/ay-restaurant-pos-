export const DB_NAME='AY_Restaurant_POS';export const DB_VERSION=2;
export const STORES=['users','roles','permissions','categories','products','product_variants','ingredients','recipes','inventory','inventory_transactions','suppliers','purchases','purchase_items','customers','tables','orders','order_items','payments','expenses','settings','audit_logs'] as const;
export type StoreName=typeof STORES[number];
let dbp:Promise<IDBDatabase>|null=null;
export function openDB():Promise<IDBDatabase>{
 if(!dbp)dbp=new Promise((res,rej)=>{const r=indexedDB.open(DB_NAME,DB_VERSION);
  r.onupgradeneeded=()=>{const db=r.result;for(const s of STORES)if(!db.objectStoreNames.contains(s))db.createObjectStore(s,{keyPath:s==='settings'?'key':'id'});
  const t=r.transaction!;const ix=(s:string,n:string,k:string,u=false)=>{const o=t.objectStore(s);if(!o.indexNames.contains(n))o.createIndex(n,k,{unique:u})};
  ix('products','barcode','barcode');ix('products','categoryId','categoryId');ix('orders','createdAt','createdAt');ix('orders','seq','seq',true);};
  r.onsuccess=()=>res(r.result);r.onerror=()=>{dbp=null;rej(r.error)};});
 return dbp;}
async function tx<T>(s:StoreName,mode:IDBTransactionMode,fn:(st:IDBObjectStore)=>IDBRequest|void):Promise<T>{
 const db=await openDB();return new Promise((res,rej)=>{const t=db.transaction(s,mode);const rq=fn(t.objectStore(s));
  t.oncomplete=()=>res((rq?rq.result:undefined) as T);t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error);});}
export const repo={
 all:<T>(s:StoreName)=>tx<T[]>(s,'readonly',st=>st.getAll()),
 get:<T>(s:StoreName,id:string)=>tx<T|undefined>(s,'readonly',st=>st.get(id)),
 put:<T>(s:StoreName,v:T)=>tx<void>(s,'readwrite',st=>st.put(v)),
 putMany:<T>(s:StoreName,v:T[])=>tx<void>(s,'readwrite',st=>{v.forEach(x=>st.put(x))}),
 remove:(s:StoreName,id:string)=>tx<void>(s,'readwrite',st=>st.delete(id)),
 clear:(s:StoreName)=>tx<void>(s,'readwrite',st=>st.clear()),
 count:(s:StoreName)=>tx<number>(s,'readonly',st=>st.count())};
