import logo from '../assets/logo.png';import {money} from '../utils/hash';import {PAY_LABEL} from '../utils/calc';import type {Order} from '../types';
export function Receipt({order:o,restaurant}:{order:Order;restaurant:string}){
 return <div className="receipt" id="receipt"><img src={logo} alt="AY Digital Solutions"/><h3>{restaurant||'AY Restaurant POS'}</h3><div>AY Restaurant POS</div>
 <p>{o.orderNumber}<br/>{new Date(o.createdAt).toLocaleString('ar-EG')}<br/>الكاشير: {o.cashierName}</p>
 <table><thead><tr><th>الصنف</th><th>كمية</th><th>سعر</th><th>إجمالي</th></tr></thead><tbody>{o.items.map((i,k)=><tr key={k}><td>{i.name}</td><td>{i.qty}</td><td>{money(i.price)}</td><td>{money(i.qty*i.price)}</td></tr>)}</tbody></table><hr/>
 <div className="rr"><span>الإجمالي الفرعي</span><span>{money(o.subtotal)}</span></div><div className="rr"><span>الخصم</span><span>{money(o.discount)}</span></div>
 <div className="rr"><span>الضريبة</span><span>{money(o.tax)}</span></div><div className="rr big"><span>الإجمالي</span><span>{money(o.total)}</span></div><hr/>
 <div className="rr"><span>طريقة الدفع</span><span>{PAY_LABEL[o.paymentMethod]}</span></div><div className="rr"><span>المدفوع</span><span>{money(o.paidAmount)}</span></div><div className="rr"><span>الباقي</span><span>{money(o.change)}</span></div>
 <hr/><p>شكرًا لزيارتكم — AY Digital Solutions</p></div>}
