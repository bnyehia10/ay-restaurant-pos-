import {useEffect,type ReactNode} from 'react';
export function Modal({title,onClose,children}:{title:string;onClose:()=>void;children:ReactNode}){
 useEffect(()=>{const h=(e:KeyboardEvent)=>{if(e.key==='Escape')onClose()};addEventListener('keydown',h);return()=>removeEventListener('keydown',h)},[onClose]);
 return <div className="overlay" onMouseDown={e=>{if(e.target===e.currentTarget)onClose()}}><div className="modal" role="dialog" aria-modal="true"><div className="mh"><h3>{title}</h3><button className="link" onClick={onClose} aria-label="إغلاق">✕</button></div>{children}</div></div>}
export function Confirm({message,onYes,onNo}:{message:string;onYes:()=>void;onNo:()=>void}){
 return <Modal title="تأكيد" onClose={onNo}><p>{message}</p><div className="acts"><button className="btn danger" onClick={onYes}>نعم، تأكيد</button><button className="btn ghost" onClick={onNo}>إلغاء</button></div></Modal>}
export function StateBox({loading,error,empty,children}:{loading:boolean;error:string;empty?:string;children:ReactNode}){
 if(loading)return <div className="card empty">جارٍ التحميل...</div>;if(error)return <div className="card empty err">حدث خطأ: {error}</div>;
 if(empty)return <div className="card empty">{empty}</div>;return <>{children}</>}
