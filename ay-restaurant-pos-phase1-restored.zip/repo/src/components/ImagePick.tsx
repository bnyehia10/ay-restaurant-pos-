import {useToast} from './Toast';
export function ImagePick({value,onChange}:{value?:string;onChange:(v?:string)=>void}){const toast=useToast();
 return <div className="imgpick">{value&&<img src={value} alt="" />}<input type="file" accept="image/*" onChange={e=>{const f=e.target.files?.[0];if(!f)return;
  if(f.size>300*1024){toast('الصورة أكبر من 300KB','err');return}const r=new FileReader();r.onload=()=>onChange(String(r.result));r.readAsDataURL(f)}}/>{value&&<button type="button" className="link" onClick={()=>onChange(undefined)}>إزالة الصورة</button>}</div>}
