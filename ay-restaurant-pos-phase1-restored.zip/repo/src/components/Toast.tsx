import {createContext,useCallback,useContext,useState,type ReactNode} from 'react';
type T={id:number;msg:string;kind:'ok'|'err'};const Ctx=createContext<(m:string,k?:'ok'|'err')=>void>(()=>{});
export const useToast=()=>useContext(Ctx);
export function ToastProvider({children}:{children:ReactNode}){const[l,s]=useState<T[]>([]);
 const add=useCallback((msg:string,kind:'ok'|'err'='ok')=>{const id=Date.now()+Math.random();s(x=>[...x,{id,msg,kind}]);setTimeout(()=>s(x=>x.filter(i=>i.id!==id)),3500)},[]);
 return <Ctx.Provider value={add}>{children}<div className="toasts">{l.map(t=><div key={t.id} className={'toast '+t.kind}>{t.msg}</div>)}</div></Ctx.Provider>;}
