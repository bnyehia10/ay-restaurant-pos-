import type {Category,Product,Role,RestaurantTable} from '../types';
// DEMO DATA — prices are placeholders, not real.
export const DEMO_CATEGORIES:Category[]=[['c1','برجر','#2f7bff'],['c2','بيتزا','#12c8f0'],['c3','فراخ','#f59e0b'],['c4','وجبات','#10b981'],['c5','مقبلات','#8b5cf6'],['c6','مشروبات','#06b6d4'],['c7','حلويات','#ec4899']].map(([id,name,color])=>({id,name,color,active:true}));
const p=(i:number,name:string,c:string,price:number,cost:number,st:string):Product=>({id:'p'+i,name,categoryId:c,sellingPrice:price,costPrice:cost,unit:'قطعة',active:true,hasRecipe:false,kitchenStation:st,createdAt:0,updatedAt:0,isDemo:true});
export const DEMO_PRODUCTS:Product[]=[p(1,'برجر كلاسيك','c1',85,40,'grill'),p(2,'تشيز برجر','c1',95,45,'grill'),p(3,'دبل برجر','c1',130,65,'grill'),p(4,'بيتزا مارجريتا','c2',110,45,'oven'),p(5,'بيتزا تشيكن','c2',135,60,'oven'),p(6,'وجبة فراخ','c3',120,55,'fry'),p(7,'بطاطس','c5',35,10,'fry'),p(8,'كولا','c6',20,10,''),p(9,'بيبسي','c6',20,10,''),p(10,'مياه','c6',10,4,''),p(11,'مولتن كيك','c7',75,30,'oven')];
const all=['dashboard','pos','orders','tables','kitchen','products','categories','inventory','recipes','purchases','suppliers','customers','expenses','reports','users','settings','backup','about'];
export const ROLES:Role[]=[{id:'ADMIN',name:'مدير النظام',permissions:all},{id:'MANAGER',name:'مدير',permissions:all.filter(x=>x!=='users')},
{id:'CASHIER',name:'كاشير',permissions:['dashboard','pos','orders','tables','customers','settings','about']},{id:'KITCHEN',name:'مطبخ',permissions:['kitchen','orders','about']}];
export const DEMO_TABLES:RestaurantTable[]=Array.from({length:8},(_,i)=>({id:'t'+(i+1),name:'طاولة '+(i+1),seats:4,status:'free' as const}));
export const DEMO_DASH={sales:12480,orders:96,cash:8130,card:4350,expenses:1900,
 top:[['برجر كلاسيك',41],['بيتزا مارجريتا',33],['بطاطس',29],['وجبة فراخ',24],['كولا',22]] as [string,number][],
 live:[['#1042','طاولة 3','في المطبخ'],['#1043','تيك أواي','جديد'],['#1044','دليفري','في المطبخ']],
 low:[['جبنة موزاريلا','2 كجم'],['لحم مفروم','4 كجم'],['علب كولا','12 علبة']]};
