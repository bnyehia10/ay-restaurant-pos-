import {repo} from '../database/db';
export async function getSetting<T>(k:string,d:T):Promise<T>{const s=await repo.get<{value:T}>('settings',k);return s?s.value:d}
export const setSetting=(key:string,value:unknown)=>repo.put('settings',{key,value});
export const getTaxRate=()=>getSetting<number>('taxRate',0);
