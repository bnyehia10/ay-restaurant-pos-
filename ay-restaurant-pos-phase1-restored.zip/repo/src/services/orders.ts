import {openDB,repo} from '../database/db';import {uid} from '../utils/hash';import type {Order,Expense} from '../types';
export type NewOrder=Omit<Order,'id'|'orderNumber'|'seq'|'createdAt'|'status'>;
/** Atomic: increments the sequence counter and saves the order in ONE transaction. */
export async function createOrder(input:NewOrder):Promise<Order>{
 const db=await openDB();
 return new Promise((res,rej)=>{const t=db.transaction(['settings','orders'],'readwrite');const st=t.objectStore('settings');const g=st.get('orderSeq');
  let o:Order;g.onsuccess=()=>{const seq=((g.result?.value as number)||0)+1;
   o={...input,id:uid(),seq,orderNumber:'ORD-'+String(seq).padStart(6,'0'),status:'completed',createdAt:Date.now()};
   st.put({key:'orderSeq',value:seq});t.objectStore('orders').put(o)};
  t.oncomplete=()=>res(o);t.onerror=()=>rej(t.error);t.onabort=()=>rej(t.error)});}
export async function listOrders(){return (await repo.all<Order>('orders')).sort((a,b)=>b.seq-a.seq)}
export async function todayStats(){
 const s=new Date();s.setHours(0,0,0,0);const from=s.getTime();
 const all=await listOrders();const o=all.filter(x=>x.status==='completed'&&x.createdAt>=from);
 const sum=(f:(x:Order)=>boolean)=>o.filter(f).reduce((a,x)=>a+x.total,0);const sales=sum(()=>true);
 const exp=(await repo.all<Expense>('expenses')).filter(e=>e.createdAt>=from).reduce((a,e)=>a+e.amount,0);
 const m=new Map<string,number>();o.forEach(x=>x.items.forEach(i=>m.set(i.name,(m.get(i.name)||0)+i.qty)));
 return{sales,count:o.length,avg:o.length?sales/o.length:0,cash:sum(x=>x.paymentMethod==='cash'),card:sum(x=>x.paymentMethod==='card'),expenses:exp,
  top:[...m.entries()].sort((a,b)=>b[1]-a[1]).slice(0,5),recent:all.slice(0,4)};}
