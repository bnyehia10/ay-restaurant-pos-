import {repo} from '../database/db';import {hashPassword,newSalt} from '../utils/hash';import type {User,Role} from '../types';
const KEY='ay_session';
export async function login(username:string,pw:string):Promise<User|null>{
 const u=(await repo.all<User>('users')).find(x=>x.username===username&&x.active);if(!u)return null;
 if(await hashPassword(pw,u.salt)!==u.passwordHash)return null;localStorage.setItem(KEY,u.id);return u;}
export const logout=()=>localStorage.removeItem(KEY);
export async function restoreSession(){const id=localStorage.getItem(KEY);return id?(await repo.get<User>('users',id))??null:null;}
export async function changePassword(u:User,pw:string){const salt=newSalt();await repo.put('users',{...u,salt,passwordHash:await hashPassword(pw,salt),isDevDefault:false});}
export async function can(u:User,page:string){const r=await repo.get<Role>('roles',u.role);return !!r?.permissions.includes(page);}
