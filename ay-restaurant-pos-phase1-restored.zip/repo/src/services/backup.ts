import {repo,STORES} from '../database/db';
export async function exportDatabase(){const data:Record<string,unknown[]>={};for(const s of STORES)data[s]=await repo.all(s);
 const blob=new Blob([JSON.stringify({app:'AY_Restaurant_POS',version:1,exportedAt:new Date().toISOString(),data},null,2)],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`ay-pos-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href);}
export async function importDatabase(file:File){const j=JSON.parse(await file.text());
 if(j.app!=='AY_Restaurant_POS'||!j.data)throw new Error('ملف النسخة الاحتياطية غير صالح');
 for(const s of STORES){if(Array.isArray(j.data[s])){await repo.clear(s);await repo.putMany(s,j.data[s]);}}}
