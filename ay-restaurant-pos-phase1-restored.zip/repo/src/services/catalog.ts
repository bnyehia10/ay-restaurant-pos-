import {repo} from '../database/db';import {uid} from '../utils/hash';import type {Category,Product} from '../types';
export async function saveCategory(c:Partial<Category>){
 const name=c.name?.trim();if(!name)throw new Error('اسم القسم مطلوب');
 if((await repo.all<Category>('categories')).some(x=>x.name===name&&x.id!==c.id))throw new Error('يوجد قسم بنفس الاسم');
 const old=c.id?await repo.get<Category>('categories',c.id):undefined;const now=Date.now();
 await repo.put<Category>('categories',{id:c.id??uid(),name,color:c.color||'#2f7bff',image:c.image,active:c.active??true,createdAt:old?.createdAt??now,updatedAt:now});}
export async function deleteCategory(id:string){
 const n=(await repo.all<Product>('products')).filter(p=>p.categoryId===id).length;
 if(n>0)throw new Error(`لا يمكن حذف هذا القسم لأنه مرتبط بعدد ${n} صنف. انقل الأصناف أو احذفها أولًا.`);
 await repo.remove('categories',id);}
export interface ProductInput extends Partial<Omit<Product,'sellingPrice'|'costPrice'>>{sellingPrice:string;costPrice:string}
export async function saveProduct(i:ProductInput){
 const name=i.name?.trim();if(!name)throw new Error('اسم الصنف مطلوب');
 if(!i.categoryId)throw new Error('القسم مطلوب');
 const sp=Number(i.sellingPrice),cp=Number(i.costPrice||0);
 if(i.sellingPrice===''||!(sp>=0))throw new Error('سعر البيع يجب أن يكون رقمًا أكبر من أو يساوي صفر');
 if(!(cp>=0))throw new Error('سعر التكلفة يجب أن يكون رقمًا أكبر من أو يساوي صفر');
 const bc=i.barcode?.trim();
 if(bc&&(await repo.all<Product>('products')).some(p=>p.barcode===bc&&p.id!==i.id))throw new Error('الباركود مستخدم لصنف آخر');
 const old=i.id?await repo.get<Product>('products',i.id):undefined;const now=Date.now();
 await repo.put<Product>('products',{id:i.id??uid(),name,barcode:bc||undefined,categoryId:i.categoryId,sellingPrice:sp,costPrice:cp,unit:i.unit||'قطعة',image:i.image,active:i.active??true,description:i.description,hasRecipe:!!i.hasRecipe,kitchenStation:i.kitchenStation||'',createdAt:old?.createdAt??now,updatedAt:now,isDemo:old?.isDemo});}
