import {useEffect,useState,type ReactNode} from 'react';import type {User} from '../types';import logo from '../assets/logo.png';
import {logout,can} from '../services/auth';import {repo} from '../database/db';import {useNow,useOnline} from '../hooks/useOnline';
import Dashboard from '../pages/Dashboard';import Backup from '../pages/Backup';import Settings from '../pages/Settings';import About from '../pages/About';import Categories from '../pages/Categories';import Products from '../pages/Products';import POS from '../pages/POS';import Orders from '../pages/Orders';import Placeholder from '../pages/Placeholder';
const NAV:[string,string,string][]=[['dashboard','الرئيسية','▦'],['pos','الكاشير','◉'],['orders','الطلبات','☰'],['tables','الطاولات','▣'],['kitchen','المطبخ','♨'],['products','الأصناف','❖'],['categories','الأقسام','◈'],['inventory','المخزون','▤'],['recipes','الوصفات','✎'],['purchases','المشتريات','⇩'],['suppliers','الموردين','⚙'],['customers','العملاء','☺'],['expenses','المصروفات','−'],['reports','التقارير','▲'],['users','المستخدمين','♟'],['settings','الإعدادات','✱'],['backup','النسخ الاحتياطي','⟳'],['about','حول البرنامج','ⓘ']];
export default function AppLayout({user,onLogout}:{user:User;onLogout:()=>void}){
 const[page,setPage]=useState(()=>location.hash.slice(1)||'dashboard');const[allowed,setAllowed]=useState<string[]>([]);const[name,setName]=useState('');const[open,setOpen]=useState(false);
 const now=useNow(),online=useOnline();
 useEffect(()=>{(async()=>{const a:string[]=[];for(const[k]of NAV)if(await can(user,k))a.push(k);setAllowed(a);const s=await repo.get<{value:string}>('settings','restaurantName');setName(s?.value??'')})()},[user]);
 useEffect(()=>{const h=()=>setPage(location.hash.slice(1)||'dashboard');addEventListener('hashchange',h);return()=>removeEventListener('hashchange',h)},[]);
 const go=(k:string)=>{location.hash=k;setOpen(false)};const title=NAV.find(n=>n[0]===page)?.[1]??'';
 let view:ReactNode;if(allowed.length&&!allowed.includes(page))view=<Placeholder title="غير مصرح لك بدخول هذه الصفحة"/>;
 else if(page==='dashboard')view=<Dashboard/>;else if(page==='categories')view=<Categories/>;else if(page==='products')view=<Products/>;else if(page==='pos')view=<POS user={user}/>;else if(page==='orders')view=<Orders/>;else if(page==='backup')view=<Backup/>;else if(page==='settings')view=<Settings user={user}/>;else if(page==='about')view=<About/>;else view=<Placeholder title={title}/>;
 return <div className="shell"><aside className={'side'+(open?' open':'')}><div className="brand"><img src={logo} alt="AY"/><b>AY POS</b></div>
 <nav>{NAV.filter(n=>allowed.includes(n[0])).map(([k,l,i])=><button key={k} className={k===page?'on':''} onClick={()=>go(k)}><span>{i}</span>{l}</button>)}</nav></aside>
 <div className="main"><header className="top"><button className="menu" onClick={()=>setOpen(!open)} aria-label="القائمة">☰</button><b>{name||'AY Restaurant POS'}</b><span>{user.name}</span>
 <span>{now.toLocaleDateString('ar-EG')}</span><span>{now.toLocaleTimeString('ar-EG')}</span><span className={'dot '+(online?'on':'off')}>● {online?'متصل (لا يلزم)':'يعمل بدون إنترنت'}</span>
 <button className="link" onClick={()=>{if(confirm('تسجيل الخروج؟')){logout();onLogout()}}}>خروج</button></header><main className="content"><h1>{title}</h1>{view}</main></div></div>}
