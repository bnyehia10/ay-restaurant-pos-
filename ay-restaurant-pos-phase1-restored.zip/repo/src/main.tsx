import {createRoot} from 'react-dom/client';import App from './App';import './styles/app.css';import {registerSW} from 'virtual:pwa-register';
registerSW({immediate:true});createRoot(document.getElementById('root')!).render(<App/>);
