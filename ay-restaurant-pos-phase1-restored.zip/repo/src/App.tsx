import {useEffect,useState} from 'react';import type {User} from './types';
import {initDatabase} from './database/seed';import {restoreSession} from './services/auth';
import {ToastProvider} from './components/Toast';import Splash from './pages/Splash';import Login from './pages/Login';import AppLayout from './layouts/AppLayout';
export default function App(){
 const[phase,setPhase]=useState<'splash'|'login'|'app'>('splash');const[user,setUser]=useState<User|null>(null);const[err,setErr]=useState('');
 useEffect(()=>{const min=new Promise(r=>setTimeout(r,1800));
  (async()=>{try{await initDatabase();const u=await restoreSession();await min;if(u){setUser(u);setPhase('app')}else setPhase('login')}catch(e){setErr('تعذر فتح قاعدة البيانات المحلية: '+(e as Error).message)}})()},[]);
 if(err)return <div className="center"><div className="card err">{err}</div></div>;
 return <ToastProvider>{phase==='splash'?<Splash/>:phase==='login'||!user?<Login onDone={u=>{setUser(u);setPhase('app')}}/>:<AppLayout user={user} onLogout={()=>{setUser(null);setPhase('login')}}/>}</ToastProvider>;}
