export type DiscountType='none'|'percent'|'fixed';
export const round2=(n:number)=>Math.round((n+Number.EPSILON)*100)/100;
export const PAY_LABEL={cash:'نقدي',card:'بطاقة',credit:'آجل'} as const;
/** Pure totals calculation. taxRate is a fraction (0.14 = 14%). */
export function calculateTotals(lines:{qty:number;price:number}[],type:DiscountType,value:number,taxRate:number){
 const subtotal=round2(lines.reduce((a,l)=>a+l.qty*l.price,0));
 const raw=type==='percent'?subtotal*Math.min(Math.max(value,0),100)/100:type==='fixed'?Math.min(Math.max(value,0),subtotal):0;
 const discount=round2(raw);const tax=round2((subtotal-discount)*Math.max(taxRate,0));
 return{subtotal,discount,tax,total:round2(subtotal-discount+tax)};}
