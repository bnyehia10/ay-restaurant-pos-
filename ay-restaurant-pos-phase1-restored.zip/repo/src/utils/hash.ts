// Password hashing abstraction (PBKDF2-SHA256 via Web Crypto). Swap implementation here only.
// Note: crypto.subtle requires a secure context (https or localhost).
const hex=(b:ArrayBuffer)=>[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('');
export const newSalt=()=>hex(crypto.getRandomValues(new Uint8Array(16)).buffer);
export async function hashPassword(pw:string,salt:string){
 const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(pw),'PBKDF2',false,['deriveBits']);
 return hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:new TextEncoder().encode(salt),iterations:100000},k,256));}
export const uid=()=>crypto.randomUUID();
export const money=(n:number)=>new Intl.NumberFormat('ar-EG',{style:'currency',currency:'EGP',maximumFractionDigits:2}).format(n);
